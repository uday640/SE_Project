"""Financial requirements assistant prototype."""
