"""Independent pipeline services."""
